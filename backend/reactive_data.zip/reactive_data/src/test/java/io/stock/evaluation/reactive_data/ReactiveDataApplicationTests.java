package io.stock.evaluation.reactive_data;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
