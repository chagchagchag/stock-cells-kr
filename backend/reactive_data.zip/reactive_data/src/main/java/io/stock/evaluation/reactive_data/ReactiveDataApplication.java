package io.stock.evaluation.reactive_data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactiveDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactiveDataApplication.class, args);
	}

}
